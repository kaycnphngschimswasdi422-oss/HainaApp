package com.haina;

public class ModeSelectActivity
{
}