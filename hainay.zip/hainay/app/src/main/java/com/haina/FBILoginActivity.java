package com.haina;

public class FBILoginActivity
{
}