package com.haina;

public class ScanActivity
{
}