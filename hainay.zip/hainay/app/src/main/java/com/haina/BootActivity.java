package com.haina;

public class BootActivity
{
}