package com.haina;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends Activity {

    EditText keyInput;
    Button loginBtn;
    TextView statusText;

    String MASTER_KEY = "HACK-2026";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        keyInput = findViewById(R.id.keyInput);
        loginBtn = findViewById(R.id.loginBtn);
        statusText = findViewById(R.id.statusText);

        loginBtn.setOnClickListener(new android.view.View.OnClickListener() {
				@Override
				public void onClick(android.view.View v) {

					String input = keyInput.getText().toString();

					if (input.equals(MASTER_KEY)) {
						statusText.setText("ACCESS GRANTED");

						startActivity(new Intent(LoginActivity.this, MainActivity.class));
						finish();

					} else {
						statusText.setText("ACCESS DENIED");
					}
				}
			});
    }
}
